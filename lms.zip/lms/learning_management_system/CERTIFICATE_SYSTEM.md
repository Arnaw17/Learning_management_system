# Course Completion Certificate System

## Overview
The certificate system automatically generates course completion certificates for students who complete all lessons in a course. Certificates include QR codes for verification and can be downloaded as PDF.

## Features

### For Students
1. **Automatic Progress Tracking**
   - System tracks lesson completion automatically
   - Progress bar updates in real-time
   - Course marked as completed when all lessons are finished

2. **Certificate Generation**
   - Button appears when course is 100% complete
   - One-click certificate generation
   - Unique certificate ID for each certificate
   - QR code for verification

3. **Certificate Details**
   - Student's full name
   - Course title
   - Instructor name
   - Completion date
   - Number of lessons completed
   - Unique certificate ID
   - QR code for verification

4. **Download Options**
   - View certificate online (beautiful HTML design)
   - Download as PDF
   - Print-friendly format

### For Instructors
- Certificates are automatically tied to course completion
- No manual certificate creation needed
- View all issued certificates in admin panel

### For Administrators
- Full certificate management in Django admin
- Search by certificate ID, student name, or course
- Filter by completion date or issue date
- Cannot manually create certificates (system-generated only)

## How It Works

### Student Journey
1. **Enroll in Course** → Student enrolls in a course (free or paid)
2. **Complete Lessons** → Student completes lessons one by one
3. **Progress Updates** → Progress bar updates automatically
4. **Course Completion** → When last lesson is marked complete:
   - Course status changes to "Completed"
   - Completion message appears
   - "Generate Certificate" button shows up
5. **Generate Certificate** → Student clicks button to generate certificate:
   - Unique certificate ID created (format: CERT-2025-XXXXXXXX)
   - QR code generated with verification URL
   - Certificate details saved to database
6. **View/Download** → Student can:
   - View certificate online (beautiful design)
   - Download as PDF
   - Share certificate ID for verification

### Certificate Verification
- Anyone can verify a certificate using the QR code or certificate ID
- Public verification page shows:
  - Certificate validity
  - Student name
  - Course details
  - Completion date
  - Lessons completed

## Database Models

### Certificate Model Fields
- `enrollment` - One-to-one with Enrollment
- `student` - ForeignKey to StudentProfile
- `course` - ForeignKey to Course
- `certificate_id` - Unique ID (auto-generated)
- `student_name` - Full name on certificate
- `course_title` - Course name
- `instructor_name` - Instructor's name
- `completion_date` - Date course was completed
- `issue_date` - Date certificate was issued
- `qr_code` - QR code image file
- `verification_url` - Public verification URL
- `total_lessons` - Total lessons in course
- `completed_lessons` - Lessons completed
- `grade` - Optional grade field

## URLs

| URL | View | Description |
|-----|------|-------------|
| `/certificate/generate/<enrollment_id>/` | `generate_certificate` | Generate new certificate |
| `/certificate/view/<certificate_id>/` | `view_certificate` | View certificate online |
| `/certificate/download/<certificate_id>/` | `download_certificate` | Download PDF |
| `/certificate/verify/<certificate_id>/` | `verify_certificate` | Public verification |

## Templates

1. **certificate.html** - Beautiful certificate display
   - Professional design with borders
   - Displays all certificate details
   - Shows QR code
   - Download and back buttons

2. **certificate_verification.html** - Public verification page
   - Shows valid/invalid status
   - Displays certificate details if valid
   - Error message if not found

3. **my_courses.html** - Updated with certificate buttons
   - "Generate Certificate" for completed courses
   - "View Certificate" if already generated

4. **course_lessons.html** - Updated with completion banner
   - Shows celebration message when complete
   - Certificate generation/view button

## Dependencies

### Python Packages
```bash
pip install qrcode[pil]  # QR code generation
pip install reportlab    # PDF generation
pip install Pillow       # Image processing
```

### Django Apps
- django.contrib.admin
- django.contrib.auth
- django.contrib.contenttypes

## Configuration

### Settings Required
None - works out of the box!

### Media Files
Certificates and QR codes are stored in:
- `media/certificates/qr_codes/` - QR code images

Make sure `MEDIA_URL` and `MEDIA_ROOT` are configured in settings.py:
```python
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
```

## Admin Panel

### Certificate Admin Features
- List display: ID, student, course, dates
- Search: by certificate ID, student name, course
- Filters: completion date, issue date
- Read-only: certificate ID, QR code, verification URL
- Date hierarchy: by issue date
- Cannot add certificates manually (system-generated only)

### Viewing Certificates in Admin
1. Go to `/admin/lms/certificate/`
2. Search or filter certificates
3. Click certificate to view details
4. See QR code preview
5. Access verification URL

## Certificate Design

### HTML Certificate Features
- Professional layout with borders
- Color scheme: Blue (#1e40af) and green (#10b981)
- Watermark: "CERTIFIED" in background
- Sections:
  - Header: "CERTIFICATE of Completion"
  - Student name (large, bold)
  - Course title
  - Completion details
  - Footer: Instructor signature, QR code, certificate ID

### PDF Certificate Features
- A4 landscape orientation
- Border design with colors
- Professional typography
- QR code in bottom right
- Signature line for instructor
- Certificate ID and dates
- Verification URL in footer

## Security

### Certificate Protection
- Unique certificate IDs prevent duplication
- QR codes link to verification page
- One certificate per enrollment (can't regenerate)
- Only completed courses get certificates
- Students can only view their own certificates

### Verification System
- Public verification page
- No login required to verify
- Shows certificate details if valid
- Clear error message if invalid

## Testing

### Test Certificate Generation
1. Create a test course with 2-3 lessons
2. Enroll as a student
3. Mark all lessons as complete
4. Check that:
   - Progress shows 100%
   - Completion banner appears
   - "Generate Certificate" button shows
5. Click "Generate Certificate"
6. Verify:
   - Certificate ID is unique
   - QR code is generated
   - All details are correct
   - PDF downloads properly

### Test Verification
1. Get a certificate ID
2. Visit `/certificate/verify/<certificate_id>/`
3. Verify correct details show
4. Test with invalid ID
5. Verify error message shows

## Troubleshooting

### Issue: QR Code Not Generating
**Solution:** Make sure `qrcode` and `Pillow` are installed:
```bash
pip install qrcode[pil] Pillow
```

### Issue: PDF Download Error
**Solution:** Install reportlab:
```bash
pip install reportlab
```

### Issue: Media Files Not Showing
**Solution:** Configure media settings in settings.py and urls.py:
```python
# settings.py
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# urls.py (add in development)
from django.conf import settings
from django.conf.urls.static import static

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

### Issue: Certificate Button Not Appearing
**Solution:** Make sure:
- Course has lessons
- All lessons are marked complete
- `enrollment.is_completed` is True
- Check template has certificate button code

## Future Enhancements

### Possible Improvements
1. Email certificate to student automatically
2. Social sharing buttons
3. Certificate templates (different designs)
4. Grade calculation and display
5. Instructor signature upload
6. Certificate revocation system
7. Batch certificate generation for instructors
8. Certificate analytics dashboard
9. Custom certificate fields per course
10. Multi-language certificate support

## Support

For issues or questions:
- Check admin panel for certificate records
- Verify all migrations are applied
- Check media files permissions
- Review server logs for errors
- Test with simple course first
