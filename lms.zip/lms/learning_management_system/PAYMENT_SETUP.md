# Payment Integration Setup Guide

## Razorpay Configuration

### 1. Get Razorpay Credentials
1. Sign up at https://razorpay.com/
2. Go to Dashboard → Settings → API Keys
3. Generate Test/Live API Keys

### 2. Add to Django Settings (settings.py)

```python
# Razorpay Payment Gateway Configuration
RAZORPAY_KEY_ID = 'your_razorpay_key_id_here'  # Replace with your actual key
RAZORPAY_KEY_SECRET = 'your_razorpay_key_secret_here'  # Replace with your actual secret

# For testing, use test keys (starts with rzp_test_)
# For production, use live keys (starts with rzp_live_)
```

### 3. Install Required Package

```bash
pip install razorpay
```

### 4. Test Payment Flow

**Test Mode Credentials (for testing):**
- Any email
- Test Card: 4111 1111 1111 1111
- CVV: Any 3 digits
- Expiry: Any future date

### 5. Security Recommendations

1. **Never commit credentials to Git:**
   - Add settings.py to .gitignore
   - Use environment variables in production:
   
   ```python
   import os
   RAZORPAY_KEY_ID = os.environ.get('RAZORPAY_KEY_ID')
   RAZORPAY_KEY_SECRET = os.environ.get('RAZORPAY_KEY_SECRET')
   ```

2. **Use HTTPS in production**
3. **Verify payment signatures** (already implemented in views.py)
4. **Log all transactions** (Payment model tracks this)

### 6. Alternative Payment Gateways

**Stripe Configuration (if you prefer Stripe):**

```python
# In settings.py
STRIPE_PUBLIC_KEY = 'pk_test_...'
STRIPE_SECRET_KEY = 'sk_test_...'
```

Install: `pip install stripe`

**PayPal Configuration:**

```python
# In settings.py
PAYPAL_CLIENT_ID = 'your_paypal_client_id'
PAYPAL_SECRET = 'your_paypal_secret'
PAYPAL_MODE = 'sandbox'  # or 'live'
```

Install: `pip install paypalrestsdk`

## Features Implemented

✅ Multiple payment methods (Razorpay, Card)
✅ Secure payment page with SSL encryption note
✅ Payment success/failure pages
✅ Transaction tracking in database
✅ Automatic enrollment after successful payment
✅ Free course enrollment (bypasses payment)
✅ Duplicate enrollment prevention
✅ Payment history in Payment model
✅ User-friendly payment UI with loading indicators

## Payment Flow

1. User clicks "Buy Now" on course detail page
2. System checks if user is logged in
3. For paid courses → Redirect to payment page
4. For free courses → Enroll directly
5. User selects payment method (Razorpay/Card)
6. Payment processed
7. On success:
   - Create Enrollment record
   - Create Payment record
   - Redirect to success page
8. On failure:
   - Show error message
   - Redirect to failure page

## Testing the Payment System

1. Start Django server: `python manage.py runserver`
2. Visit http://localhost:8000/courses/explore/
3. Click on a paid course
4. Click "Buy Now"
5. Select payment method
6. For Razorpay: Click "Pay with Razorpay" and use test credentials
7. For Card: Enter dummy card details
8. Verify enrollment in "My Courses"

## Database Schema

**Payment Model Fields:**
- student (ForeignKey to StudentProfile)
- course (ForeignKey to Course)
- enrollment (OneToOneField to Enrollment)
- amount (Decimal)
- currency (String)
- payment_method (Choice: razorpay/stripe/credit_card)
- status (Choice: pending/completed/failed/refunded)
- transaction_id (Unique identifier)
- billing_name
- billing_email
- created_at, updated_at, completed_at

## Admin Panel

To view payments in Django Admin, register the Payment model:

```python
# In lms/admin.py
from django.contrib import admin
from .models import Payment

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['transaction_id', 'student', 'course', 'amount', 'status', 'created_at']
    list_filter = ['status', 'payment_method', 'created_at']
    search_fields = ['transaction_id', 'student__user__username', 'course__title']
    readonly_fields = ['transaction_id', 'created_at', 'updated_at']
```

## Troubleshooting

**Issue:** "RAZORPAY_KEY_ID not found"
**Solution:** Add credentials to settings.py

**Issue:** Payment succeeds but enrollment fails
**Solution:** Check Payment model in admin panel, verify student profile exists

**Issue:** Razorpay popup doesn't open
**Solution:** Check browser console for JavaScript errors, verify Razorpay script is loaded

**Issue:** "already enrolled" message
**Solution:** This is correct - prevents duplicate charges. Check "My Courses" for access.

## Next Steps

1. Add email notifications for successful payments
2. Add invoice generation (PDF)
3. Add refund functionality
4. Add payment analytics dashboard
5. Add coupon/discount code system
6. Add subscription/recurring payments
7. Add payment receipt download
