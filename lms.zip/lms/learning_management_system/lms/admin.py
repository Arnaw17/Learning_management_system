from django.contrib import admin
from .models import StudentProfile, InstructorProfile, Course, CourseModule, Lesson, Enrollment, LessonProgress, Payment, Certificate, SupportTicket
from django.contrib import messages
from django.contrib.auth.models import Group # Imported but unused (often happens)
from django.db.models import Count

# --- 1. Inline Models for Course Structure ---

class LessonInline(admin.TabularInline):
    """Allows lessons to be added/edited directly on the CourseModule page."""
    model = Lesson
    extra = 1 
    fields = ('title', 'lesson_type', 'duration_minutes', 'order')


class CourseModuleInline(admin.TabularInline):
    """Allows modules to be added/edited directly on the Course page."""
    model = CourseModule
    extra = 1 
    fields = ('title', 'description', 'order')


# --- 2. Inline Model for Student Engagement ---

class LessonProgressInline(admin.TabularInline):
    """Allows viewing/managing lesson progress directly on the Enrollment record."""
    model = LessonProgress
    extra = 0 
    fields = ('lesson', 'is_completed', 'completion_date')
    readonly_fields = ('completion_date',)
    raw_id_fields = ('lesson',) # Efficient lookup for lessons

class EnrollmentInline(admin.TabularInline):
    """Allows viewing and managing students enrolled in a Course."""
    model = Enrollment
    extra = 0 # Do not show extra empty forms by default
    fields = ('student', 'enrollment_date', 'is_completed')
    readonly_fields = ('enrollment_date',)
    # Use raw_id_fields for student lookup, very efficient for many students
    raw_id_fields = ('student',) 


# --- 3. Actions ---

def approve_instructors(modeladmin, request, queryset):
    updated = 0
    for profile in queryset:
        if not profile.approved:
            profile.approved = True
            profile.save()
            user = profile.user
            user.is_staff = True
            user.save()
            updated += 1
    messages.success(request, f"{updated} instructor(s) approved and promoted to staff.")


approve_instructors.short_description = 'Approve selected instructors'


# --- 4. Model Admin Classes ---

@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    # Recommended: Add an Enrollment Inline to see which courses the student is taking
    inlines = [EnrollmentInline] 
    list_display = ('user', 'contact', 'dob', 'created_at')
    
    def delete_model(self, request, obj):
        """When deleting StudentProfile, also delete the associated User."""
        user = obj.user
        super().delete_model(request, obj)
        if user and not hasattr(user, 'instructor_profile'):
            # Only delete user if they don't have an instructor profile
            user.delete()
    
    def delete_queryset(self, request, queryset):
        """Handle bulk deletion of StudentProfiles and their associated Users."""
        from django.contrib.auth import get_user_model
        User = get_user_model()
        user_ids = []
        for profile in queryset:
            user = profile.user
            # Collect user IDs that don't have instructor profiles
            if user and not hasattr(user, 'instructor_profile'):
                user_ids.append(user.id)
        super().delete_queryset(request, queryset)
        # Delete orphaned users
        if user_ids:
            User.objects.filter(id__in=user_ids).delete()


@admin.register(InstructorProfile)
class InstructorProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'contact', 'expertise', 'instructor_id', 'approved', 'created_at')
    actions = [approve_instructors]

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    """Admin view for the main Course model."""
    list_display = ('title', 'instructor', 'category', 'price', 'level', 'is_published', 'student_count', 'created_at')
    list_filter = ('level', 'category', 'is_published', 'created_at')
    search_fields = ('title', 'short_description', 'instructor__user__username')
    prepopulated_fields = {'slug': ('title',)}
    
    # Organize fields into fieldsets for better layout
    fieldsets = (
        ('Course Identification', {
            'fields': ('title', 'slug', 'instructor', 'category', 'level'),
        }),
        ('Description & Media', {
            # FIX: Changed 'thumbnail' to 'image' based on your models.py
            'fields': ('short_description', 'detailed_description', 'image', 'course_video', 'notes_file'),
        }),
        ('Pricing & Status', {
            'fields': ('price', 'is_published'),
        }),
    )

    # Use inlines to add/edit modules AND view enrollments directly on the Course page
    inlines = [CourseModuleInline, EnrollmentInline]
    
    # New Method: Display the count of enrolled students in the list view
    def get_queryset(self, request):
        # Annotate queryset with the count of related Enrollment objects
        return super().get_queryset(request).annotate(
            _student_count=Count('enrollments', distinct=True)
        )

    def student_count(self, obj):
        # Access the annotated count
        return obj._student_count
    
    student_count.admin_order_field = '_student_count'
    student_count.short_description = 'Enrolled Students'


@admin.register(CourseModule)
class CourseModuleAdmin(admin.ModelAdmin):
    """Admin view for Course Modules, including lesson inlines."""
    list_display = ('title', 'course', 'order')
    list_filter = ('course',)
    search_fields = ('title',)
    
    inlines = [LessonInline]

@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    """Admin view for individual Lessons with video and PDF management."""
    list_display = ('title', 'module', 'lesson_type', 'duration_minutes', 'order', 'has_video', 'has_notes')
    list_filter = ('lesson_type', 'module__course', 'order')
    search_fields = ('title', 'module__title', 'module__course__title')
    
    fieldsets = (
        ('Lesson Details', {
            'fields': ('title', 'module', 'lesson_type', 'order', 'duration_minutes'),
        }),
        ('Content', {
            'fields': ('content_text', 'content_url', 'video_file', 'notes_pdf'),
            'description': 'Upload video files (MP4, WebM, AVI) and PDF notes for students to access.',
        }),
    )
    
    def has_video(self, obj):
        """Show if lesson has video file."""
        if obj.video_file:
            return '✓ Yes'
        return '✗ No'
    has_video.short_description = 'Has Video'
    
    def has_notes(self, obj):
        """Show if lesson has notes PDF."""
        if obj.notes_pdf:
            return '✓ Yes'
        return '✗ No'
    has_notes.short_description = 'Has Notes'

@admin.register(LessonProgress)
class LessonProgressAdmin(admin.ModelAdmin):
    """Admin view for tracking student lesson progress."""
    list_display = ('student_name', 'course_name', 'lesson_title', 'is_completed', 'completion_date')
    list_filter = ('is_completed', 'completion_date', 'enrollment__course')
    search_fields = ('enrollment__student__user__username', 'lesson__title', 'enrollment__course__title')
    readonly_fields = ('enrollment', 'lesson', 'completion_date')
    
    fieldsets = (
        ('Progress Information', {
            'fields': ('enrollment', 'lesson', 'is_completed', 'completion_date'),
        }),
    )
    
    def student_name(self, obj):
        """Display student name."""
        return obj.enrollment.student.user.get_full_name() or obj.enrollment.student.user.username
    student_name.short_description = 'Student'
    student_name.admin_order_field = 'enrollment__student__user__username'
    
    def course_name(self, obj):
        """Display course name."""
        return obj.enrollment.course.title
    course_name.short_description = 'Course'
    course_name.admin_order_field = 'enrollment__course__title'
    
    def lesson_title(self, obj):
        """Display lesson title."""
        return obj.lesson.title
    lesson_title.short_description = 'Lesson'
    lesson_title.admin_order_field = 'lesson__title'

@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    """Admin view for student enrollments with lesson progress tracking."""
    list_display = ('student', 'course', 'progress_percentage', 'enrollment_date', 'is_completed')
    list_filter = ('enrollment_date', 'is_completed', 'course', 'progress_percentage')
    search_fields = ('student__user__username', 'course__title')
    raw_id_fields = ('student', 'course')
    readonly_fields = ('enrollment_date', 'progress_percentage')
    
    fieldsets = (
        ('Enrollment Info', {
            'fields': ('student', 'course', 'enrollment_date'),
        }),
        ('Progress Tracking', {
            'fields': ('progress_percentage', 'is_completed', 'completion_date'),
        }),
    )
    
    inlines = [LessonProgressInline]


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    """Admin view for payment transactions with comprehensive tracking."""
    list_display = ('transaction_id', 'billing_name', 'course', 'amount', 'status', 'payment_method', 'billing_phone', 'created_at')
    list_filter = ('status', 'payment_method', 'created_at', 'currency')
    search_fields = ('transaction_id', 'razorpay_payment_id', 'razorpay_order_id', 'student__user__username', 'student__user__email', 'course__title', 'billing_email', 'billing_name', 'billing_phone')
    readonly_fields = ('transaction_id', 'razorpay_payment_id', 'razorpay_order_id', 'razorpay_signature', 'created_at', 'updated_at', 'completed_at')
    raw_id_fields = ('student', 'course', 'enrollment')
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Transaction Details', {
            'fields': ('transaction_id', 'status', 'payment_method'),
        }),
        ('Student & Course', {
            'fields': ('student', 'course', 'enrollment'),
        }),
        ('Payment Information', {
            'fields': ('amount', 'currency', 'razorpay_order_id', 'razorpay_payment_id', 'razorpay_signature'),
        }),
        ('Customer Billing Details', {
            'fields': ('billing_name', 'billing_email', 'billing_phone'),
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at', 'completed_at'),
        }),
    )
    
    def has_add_permission(self, request):
        # Prevent manual payment creation through admin (payments should be created via payment flow)
        return False


@admin.register(Certificate)
class CertificateAdmin(admin.ModelAdmin):
    """Admin view for course completion certificates."""
    list_display = ('certificate_id', 'student_name', 'course_title', 'completion_date', 'issue_date')
    list_filter = ('completion_date', 'issue_date')
    search_fields = ('certificate_id', 'student_name', 'course_title', 'student__user__username', 'student__user__email')
    readonly_fields = ('certificate_id', 'qr_code', 'verification_url', 'issue_date')
    raw_id_fields = ('student', 'course', 'enrollment')
    date_hierarchy = 'issue_date'
    
    fieldsets = (
        ('Certificate Details', {
            'fields': ('certificate_id', 'student_name', 'course_title', 'instructor_name'),
        }),
        ('Related Records', {
            'fields': ('student', 'course', 'enrollment'),
        }),
        ('Dates', {
            'fields': ('completion_date', 'issue_date'),
        }),
        ('Course Progress', {
            'fields': ('total_lessons', 'completed_lessons', 'grade'),
        }),
        ('Verification', {
            'fields': ('qr_code', 'verification_url'),
        }),
    )
    
    def has_add_permission(self, request):
        # Prevent manual certificate creation (should be generated via system)
        return False


# --- 10. SupportTicket Admin ---

@admin.register(SupportTicket)
class SupportTicketAdmin(admin.ModelAdmin):
    list_display = ('ticket_id', 'subject', 'user', 'email', 'phone', 'status', 'created_at', 'closed_at')
    list_filter = ('status', 'created_at', 'closed_at')
    search_fields = ('ticket_id', 'subject', 'email', 'phone', 'user__username', 'user__email', 'message')
    readonly_fields = ('ticket_id', 'created_at', 'closed_at', 'user')
    list_editable = ('status',)
    date_hierarchy = 'created_at'
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Ticket Information', {
            'fields': ('ticket_id', 'status', 'subject'),
        }),
        ('User Details', {
            'fields': ('user', 'name', 'email', 'phone'),
        }),
        ('Message', {
            'fields': ('message',),
            'classes': ('wide',),
        }),
        ('Resolution', {
            'fields': ('admin_notes', 'closed_by', 'closed_at'),
            'classes': ('wide',),
        }),
        ('Timestamps', {
            'fields': ('created_at',),
        }),
    )
    
    actions = ['mark_as_closed', 'mark_as_open']
    
    def mark_as_closed(self, request, queryset):
        """Bulk action to close tickets"""
        from django.utils import timezone
        updated = 0
        for ticket in queryset.filter(status='open'):
            ticket.status = 'closed'
            ticket.closed_at = timezone.now()
            ticket.closed_by = request.user
            ticket.save()
            updated += 1
        self.message_user(request, f'{updated} ticket(s) marked as closed.')
    mark_as_closed.short_description = "✅ Close selected tickets"
    
    def mark_as_open(self, request, queryset):
        """Bulk action to reopen tickets"""
        updated = queryset.filter(status='closed').update(
            status='open',
            closed_at=None,
            closed_by=None
        )
        self.message_user(request, f'{updated} ticket(s) reopened.')
    mark_as_open.short_description = "🔄 Reopen selected tickets"
    
    def has_delete_permission(self, request, obj=None):
        # Only superusers can delete tickets
        return request.user.is_superuser
    
    def save_model(self, request, obj, form, change):
        """Auto-set closed_by and closed_at when status changes to closed"""
        if change and obj.status == 'closed' and not obj.closed_at:
            from django.utils import timezone
            obj.closed_at = timezone.now()
            obj.closed_by = request.user
        super().save_model(request, obj, form, change)