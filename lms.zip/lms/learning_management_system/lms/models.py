from django.db import models
from django.conf import settings
from django.utils.text import slugify
import uuid

# =========================================================
# User Profile Models (No Changes Here)
# =========================================================

class StudentProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='student_profile')
    contact = models.CharField(max_length=20, blank=True)
    dob = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Many-to-Many relationship with Course via the Enrollment model
    enrolled_courses = models.ManyToManyField(
        'Course',
        through='Enrollment',
        related_name='enrolled_students'
    )

    def __str__(self):
        return f"StudentProfile({self.user.username})"


class InstructorProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='instructor_profile')
    contact = models.CharField(max_length=20, blank=True)
    expertise = models.CharField(max_length=200, blank=True)
    instructor_id = models.CharField(max_length=32, unique=True, blank=True)
    profile_image = models.ImageField(
        upload_to='instructor_profiles/', 
        null=True, 
        blank=True,
        verbose_name="Profile Picture"
    )
    approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"InstructorProfile({self.user.username})"

# =========================================================
# Course Models (No Changes Here)
# =========================================================

class Course(models.Model):
    LEVEL_CHOICES = (
        ('Beginner', 'Beginner'),
        ('Intermediate', 'Intermediate'),
        ('Advanced', 'Advanced'),
    )

    # Core details
    title = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True, blank=True)
    short_description = models.CharField(max_length=500, blank=True)
    detailed_description = models.TextField(blank=True)
    outline = models.TextField(blank=True, verbose_name="Course Outline") 
    
    # Relationships
    instructor = models.ForeignKey(InstructorProfile, on_delete=models.CASCADE, related_name='courses')
    category = models.CharField(max_length=100) 

    # Pricing and Media (Course-level files)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    image = models.ImageField(upload_to='course_thumbnails/', null=True, blank=True) 
    course_video = models.FileField(upload_to='course_videos/', null=True, blank=True)
    notes_file = models.FileField(upload_to='course_notes/', null=True, blank=True)
    
    # Status and Metadata
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES, default='Beginner')
    is_published = models.BooleanField(default=False)
    content_complete = models.BooleanField(
        default=False, 
        help_text="Mark as complete when all course content has been uploaded and course is ready for certification"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title)
            unique_slug = base_slug
            # Simple check to avoid conflicts, though collision is still possible
            if Course.objects.filter(slug=unique_slug).exists():
                 unique_slug = f'{base_slug}-{uuid.uuid4().hex[:4]}'
            self.slug = unique_slug
        super().save(*args, **kwargs)


class CourseModule(models.Model):
    """
    A section or chapter within a course.
    """
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='modules')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    order = models.PositiveIntegerField(default=0)
    
    class Meta:
        unique_together = ('course', 'order')
        ordering = ['order']

    def __str__(self):
        return f"{self.course.title}: Module {self.order} - {self.title}"


class Lesson(models.Model):
    """
    An individual unit of content (video, text, quiz) within a module.
    """
    LESSON_TYPES = (
        ('video', 'Video'),
        ('text', 'Reading/Article'),
        ('quiz', 'Quiz'),
    )
    
    module = models.ForeignKey(CourseModule, on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField(max_length=255)
    lesson_type = models.CharField(max_length=10, choices=LESSON_TYPES, default='video')
    content_url = models.URLField(max_length=500, blank=True) 
    content_text = models.TextField(blank=True) 
    duration_minutes = models.PositiveIntegerField(default=0, help_text="Duration in minutes (0 for reading)")
    order = models.PositiveIntegerField(default=0)
    
    # ADDED FIELDS: For Instructor content uploads
    video_file = models.FileField(upload_to='lesson_videos/', null=True, blank=True)
    notes_pdf = models.FileField(upload_to='lesson_notes/', null=True, blank=True)
    # END ADDED FIELDS

    class Meta:
        unique_together = ('module', 'order')
        ordering = ['order']

    def __str__(self):
        return f"{self.module.title}: Lesson {self.order} - {self.title}"

# =========================================================
# Student Enrollment/Engagement Model (MODIFIED)
# =========================================================

class Enrollment(models.Model):
    """
    Intermediate model to track student enrollment in a course.
    """
    student = models.ForeignKey(
        StudentProfile, 
        on_delete=models.CASCADE, 
        related_name='enrollments'
    )
    course = models.ForeignKey(
        Course, 
        on_delete=models.CASCADE, 
        related_name='enrollments'
    )
    enrollment_date = models.DateTimeField(auto_now_add=True)
    
    is_completed = models.BooleanField(default=False) 
    completion_date = models.DateTimeField(null=True, blank=True)

    # ADDED FIELD: Stored progress percentage (can be updated by a method)
    progress_percentage = models.PositiveSmallIntegerField(default=0, help_text="Percentage of course lessons completed (0-100)")
    # END ADDED FIELD

    class Meta:
        unique_together = ('student', 'course') 
        verbose_name = "Course Enrollment"
        verbose_name_plural = "Course Enrollments"
        ordering = ['-enrollment_date']

    def __str__(self):
        return f"{self.student.user.username} enrolled in {self.course.title}"

# =========================================================
# Lesson Progress Tracking (NEW MODEL)
# =========================================================

class LessonProgress(models.Model):
    """
    Tracks a student's completion status for individual lessons.
    This drives the calculation of the course progress percentage in Enrollment.
    """
    # Links to the specific Enrollment instance (which links student and course)
    enrollment = models.ForeignKey(
        Enrollment,
        on_delete=models.CASCADE,
        related_name='lesson_progress'
    )
    # Links to the specific Lesson
    lesson = models.ForeignKey(
        Lesson,
        on_delete=models.CASCADE,
        related_name='lesson_progresses'
    )
    is_completed = models.BooleanField(default=False)
    completion_date = models.DateTimeField(null=True, blank=True)

    class Meta:
        # A student can only have one progress entry per lesson within an enrollment
        unique_together = ('enrollment', 'lesson')
        verbose_name = "Lesson Progress"
        verbose_name_plural = "Lesson Progresses"

    def __str__(self):
        status = "Completed" if self.is_completed else "In Progress"
        return f"{self.enrollment.student.user.username}'s progress on {self.lesson.title}: {status}"


# =========================================================
# Certificate Models
# =========================================================

class Certificate(models.Model):
    """
    Course completion certificate for students
    """
    enrollment = models.OneToOneField(
        Enrollment,
        on_delete=models.CASCADE,
        related_name='certificate'
    )
    student = models.ForeignKey(
        StudentProfile,
        on_delete=models.CASCADE,
        related_name='certificates'
    )
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='certificates'
    )
    
    # Certificate details
    certificate_id = models.CharField(max_length=50, unique=True, blank=True)
    student_name = models.CharField(max_length=255, help_text="Student's full name on certificate")
    course_title = models.CharField(max_length=255, help_text="Course title on certificate")
    instructor_name = models.CharField(max_length=255, help_text="Instructor's name")
    completion_date = models.DateField(help_text="Date of course completion")
    issue_date = models.DateTimeField(auto_now_add=True)
    
    # QR Code and verification
    qr_code = models.ImageField(upload_to='certificates/qr_codes/', blank=True, null=True)
    verification_url = models.URLField(blank=True, help_text="URL for certificate verification")
    
    # Additional details
    grade = models.CharField(max_length=10, blank=True, help_text="Final grade (optional)")
    total_lessons = models.IntegerField(default=0)
    completed_lessons = models.IntegerField(default=0)
    
    class Meta:
        ordering = ['-issue_date']
        verbose_name = "Certificate"
        verbose_name_plural = "Certificates"
    
    def __str__(self):
        return f"Certificate {self.certificate_id} - {self.student_name} - {self.course_title}"
    
    def save(self, *args, **kwargs):
        if not self.certificate_id:
            # Generate unique certificate ID (e.g., CERT-2024-XXXXXX)
            from datetime import datetime
            year = datetime.now().year
            unique_part = uuid.uuid4().hex[:8].upper()
            self.certificate_id = f"CERT-{year}-{unique_part}"
        super().save(*args, **kwargs)


# =========================================================
# Payment Models
# =========================================================

class Payment(models.Model):
    """
    Tracks payment transactions for course purchases.
    """
    PAYMENT_STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    )
    
    PAYMENT_METHOD_CHOICES = (
        ('stripe', 'Stripe'),
        ('razorpay', 'Razorpay'),
        ('paypal', 'PayPal'),
        ('credit_card', 'Credit Card'),
        ('debit_card', 'Debit Card'),
    )
    
    # Core relationships
    student = models.ForeignKey(
        StudentProfile,
        on_delete=models.CASCADE,
        related_name='payments'
    )
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='payments'
    )
    enrollment = models.OneToOneField(
        Enrollment,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='payment'
    )
    
    # Payment details
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='USD')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES)
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    
    # Transaction IDs and references
    transaction_id = models.CharField(max_length=255, unique=True, blank=True)
    razorpay_order_id = models.CharField(max_length=255, blank=True, help_text="Razorpay Order ID")
    razorpay_payment_id = models.CharField(max_length=255, blank=True, help_text="Razorpay Payment ID")
    razorpay_signature = models.CharField(max_length=255, blank=True, help_text="Razorpay Signature for verification")
    payment_gateway_response = models.TextField(blank=True, help_text="Raw response from payment gateway")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    # Customer billing information
    billing_name = models.CharField(max_length=255, blank=True, help_text="Customer full name")
    billing_email = models.EmailField(blank=True, help_text="Customer email address")
    billing_phone = models.CharField(max_length=20, blank=True, help_text="Customer phone number")
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Payment"
        verbose_name_plural = "Payments"
    
    def __str__(self):
        return f"Payment {self.transaction_id} - {self.student.user.username} - {self.course.title} - {self.status}"
    
    def save(self, *args, **kwargs):
        if not self.transaction_id:
            # Generate unique transaction ID
            self.transaction_id = f"TXN-{uuid.uuid4().hex[:12].upper()}"
        super().save(*args, **kwargs)


# =========================================================
# Support Ticket Model
# =========================================================

class SupportTicket(models.Model):
    STATUS_CHOICES = (
        ('open', 'Open'),
        ('closed', 'Closed'),
    )
    
    ticket_id = models.CharField(max_length=20, unique=True, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='support_tickets')
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='open')
    created_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    admin_notes = models.TextField(blank=True, null=True)
    closed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='closed_tickets'
    )
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Support Ticket"
        verbose_name_plural = "Support Tickets"
    
    def __str__(self):
        return f"Ticket {self.ticket_id} - {self.subject} [{self.status}]"
    
    def save(self, *args, **kwargs):
        if not self.ticket_id:
            # Generate unique ticket ID
            self.ticket_id = f"TKT-{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)