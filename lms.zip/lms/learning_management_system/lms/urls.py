from django.urls import path
from . import views

urlpatterns = [
    # General User/Student Paths
    path('', views.home, name='home'),
    path('login/', views.student_login, name='student_login'),
    path('logout/', views.logout_view, name='logout_view'),
    path('register/', views.student_register, name='student_register'),
    
    # --- ADDED PATH FOR 'MY COURSES' ---
    path('my-courses/', views.my_courses_view, name='my_courses'), 
    # ------------------------------------

    # Instructor Paths
    path('instructor/login/', views.instructor_login, name='instructor_login'),
    path('instructor/register/', views.instructor_register, name='instructor_register'),
    path('instructor/dashboard/', views.instructor_dashboard, name='instructor_dashboard'),
    path('instructor/profile/edit/', views.instructor_edit_profile, name='instructor_edit_profile'),
    path('instructor/create-course/', views.instructor_create_course, name='instructor_create_course'),
    path('instructor/my-courses/', views.instructor_my_courses, name='instructor_my_courses'),
    path('instructor/edit-course/<int:pk>/', views.instructor_edit_course, name='instructor_edit_course'),
    path('instructor/delete-course/<int:pk>/', views.instructor_delete_course, name='instructor_delete_course'),
    path('instructor/manage-courses/', views.instructor_manage_courses, name='instructor_manage_courses'),
    path('instructor/add-quiz/', views.instructor_add_quiz, name='instructor_add_quiz'),
    path('instructor/create-coupon/', views.instructor_create_coupon, name='instructor_create_coupon'),
    path('instructor/engagement/', views.instructor_engagement_view, name='instructor_engagement'),
    path('instructor/request-payout/', views.instructor_request_payout, name='instructor_request_payout'),
    path('instructor/course/<slug:course_slug>/content/', views.instructor_manage_content, name='instructor_manage_content'),
    path('instructor/course/<slug:course_slug>/lesson/<int:lesson_pk>/edit/', views.instructor_edit_lesson, name='instructor_edit_lesson'),
    # Instructor view to inspect a specific student's progress in a course
    path('instructor/student/<int:student_pk>/course/<int:course_pk>/progress/', 
        views.instructor_course_progress, 
        name='course_detail_view'),
    # Course Paths
    path('courses/explore/', views.explore_courses_view, name='explore_courses'),
    path('courses/<slug:course_slug>/', views.course_detail_view, name='course_detail'),
    path('courses/<slug:course_slug>/lessons/', views.course_lessons_view, name='course_lessons'),
    path('courses/<slug:course_slug>/lesson/<int:lesson_id>/', views.lesson_detail_view, name='lesson_detail'),
    path('instructor/course/<slug:course_slug>/lesson/<int:lesson_pk>/set-duration/', views.set_lesson_duration, name='set_lesson_duration'),
    path('courses/python/', views.course_python, name='course_python'),
    path('courses/javascript/', views.course_javascript, name='course_javascript'),
    path('courses/java/', views.course_java, name='course_java'),
    path('courses/cpp/', views.course_cpp, name='course_cpp'),
    
    # Payment Paths
    path('purchase/', views.purchase_course, name='purchase_course'),
    path('payment/<int:course_id>/', views.payment_page, name='payment_page'),
    path('payment/process/', views.process_payment, name='process_payment'),
    path('payment/razorpay/process/', views.process_razorpay_payment, name='process_razorpay_payment'),
    path('payment/success/<str:payment_id>/', views.payment_success, name='payment_success'),
    path('payment/failure/', views.payment_failure, name='payment_failure'),

    # Certificate Paths
    path('certificate/generate/<int:enrollment_id>/', views.generate_certificate, name='generate_certificate'),
    path('certificate/view/<str:certificate_id>/', views.view_certificate, name='view_certificate'),
    path('certificate/download/<str:certificate_id>/', views.download_certificate, name='download_certificate'),
    path('certificate/verify/<str:certificate_id>/', views.verify_certificate, name='verify_certificate'),

    # Support and About Paths
    path('about/', views.about_us, name='about_us'),
    path('support/', views.support_page, name='support_page'),
    path('support/submit/', views.submit_support_ticket, name='submit_support_ticket'),
    path('my-tickets/', views.my_tickets, name='my_tickets'),

     # Create Razorpay order and open payment gateway (legacy - can be removed if not used)
    path('create-order/', views.create_order, name='create_order') if hasattr(views, 'create_order') else None,
    
    # Razorpay callback URL after payment (legacy - can be removed if not used)
    path('callback/', views.payment_callback, name='payment_callback') if hasattr(views, 'payment_callback') else None,
]

# Filter out None values from urlpatterns
urlpatterns = [url for url in urlpatterns if url is not None]