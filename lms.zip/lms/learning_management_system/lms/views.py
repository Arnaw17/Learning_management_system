from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_exempt
from django.views.decorators.http import require_http_methods
from django.db.models import Count, Q # Added for dashboard analytics later
from django.utils import timezone
from django import forms
from django.conf import settings
import razorpay
import json

# Initialize Razorpay client
razorpay_client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
# IMPORTANT MODEL IMPORTS
from .models import StudentProfile, InstructorProfile, Course, Enrollment, CourseModule, Lesson, LessonProgress, Payment, Certificate

# IMPORTANT FORM IMPORTS (Assuming Enrollment is correctly imported from forms.py)
from .forms import (
    StudentRegistrationForm, InstructorRegistrationForm, LoginForm, 
    CourseCreationForm, InstructorProfileEditForm,
    CourseModuleForm, LessonContentForm # <--- CRITICAL FIX: ADDED MISSING FORM IMPORTS
)

User = get_user_model()

# =========================================================
# CORE AUTH VIEWS
# =========================================================

def home(request):
    return render(request, 'lms/index.html')

@ensure_csrf_cookie
def student_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = form.cleaned_data['user']
            remember = form.cleaned_data.get('remember_me')
            login(request, user)
            if remember:
                request.session.set_expiry(1209600)
            else:
                request.session.set_expiry(0)
            return redirect('home')
        else:
            messages.error(request, form.errors.as_text())
    else:
        form = LoginForm()
    return render(request, 'lms/log.html', {'form': form})

def student_register(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Registration successful. Please log in.')
            return redirect('student_login')
    else:
        form = StudentRegistrationForm()
    return render(request, 'lms/reg.html', {'form': form})

@ensure_csrf_cookie
def instructor_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = form.cleaned_data['user']
            remember = form.cleaned_data.get('remember_me')
            profile = InstructorProfile.objects.filter(user=user).first()
            if profile and profile.approved:
                if not user.is_staff:
                    user.is_staff = True
                    user.save()
                login(request, user)
                if remember:
                    request.session.set_expiry(1209600)
                else:
                    request.session.set_expiry(0)
                return redirect('instructor_dashboard')
            if profile and not profile.approved:
                messages.error(request, 'Your instructor account is pending admin approval.')
            else:
                messages.error(request, 'You are not an instructor or your instructor profile is missing')
        else:
            messages.error(request, form.errors.as_text())
    else:
        form = LoginForm()
    return render(request, 'lms/instructorlogin.html', {'form': form})

@ensure_csrf_cookie
def instructor_register(request):
    if request.method == 'POST':
        form = InstructorRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Instructor registration successful. Please log in.')
            return redirect('instructor_login')
    else:
        form = InstructorRegistrationForm()
    return render(request, 'lms/instructorreg.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')


# =========================================================
# INSTRUCTOR DASHBOARD & COURSE MANAGEMENT VIEWS
# =========================================================

@login_required
def instructor_dashboard(request):
    try:
        profile = request.user.instructor_profile
        if not profile.approved:
            messages.error(request, 'Your instructor account is pending admin approval.')
            logout(request)
            return redirect('home')
    except InstructorProfile.DoesNotExist:
        messages.error(request, 'You do not have an instructor profile.')
        return redirect('home')

    # Fetch data for the dashboard KPI cards
    instructor_courses = Course.objects.filter(instructor=profile)
    total_courses = instructor_courses.count()
    
    # Calculate total unique students enrolled in the instructor's courses
    total_enrolled_students = Enrollment.objects.filter(
        course__in=instructor_courses
    ).values('student').annotate(count=Count('student')).count()
    
    # Fetch recent enrollments for the dashboard feed
    recent_enrollments = Enrollment.objects.filter(
        course__in=instructor_courses
    ).select_related('student__user', 'course').order_by('-enrollment_date')[:5]

    context = {
        'total_courses': total_courses,
        'total_enrolled_students': total_enrolled_students,
        'recent_enrollments': recent_enrollments,
    }

    return render(request, 'lms/instructordash.html', context)


@login_required
def instructor_create_course(request):
    try:
        instructor_profile = request.user.instructor_profile
    except InstructorProfile.DoesNotExist:
        messages.error(request, 'Instructor profile not found.')
        return redirect('instructor_dashboard')
        
    if request.method == 'POST':
        form = CourseCreationForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.instructor = instructor_profile 
            course.save()
            messages.success(request, f'Course "{course.title}" created successfully!')
            return redirect('instructor_dashboard') 
        else:
            messages.error(request, 'There was an error in the form. Please correct the fields.')
    else:
        form = CourseCreationForm() 

    context = {'form': form}
    return render(request, 'lms/instructor_create_course.html', context) 

@login_required
def instructor_my_courses(request):
    try:
        instructor_profile = get_object_or_404(InstructorProfile, user=request.user)
    except Exception:
        messages.error(request, 'You do not have a valid instructor profile.')
        return redirect('home')

    my_courses = Course.objects.filter(instructor=instructor_profile).order_by('-created_at')

    context = {
        'my_courses': my_courses,
        'profile': instructor_profile,
    }
    
    return render(request, 'lms/instructor_my_courses.html', context)

@login_required
def instructor_edit_course(request, pk):
    try:
        instructor_profile = get_object_or_404(InstructorProfile, user=request.user)
    except Exception:
        messages.error(request, 'Profile error. Please log in again.')
        return redirect('instructor_dashboard')

    course = get_object_or_404(
        Course, 
        pk=pk, 
        instructor=instructor_profile
    )

    if request.method == 'POST':
        form = CourseCreationForm(request.POST, request.FILES, instance=course)
        
        if form.is_valid():
            form.save()
            messages.success(request, f'Course "{course.title}" updated successfully! 👍')
            return redirect('instructor_my_courses')
        else:
            messages.error(request, 'Error updating course. Please check the fields.')
    
    else:
        form = CourseCreationForm(instance=course)

    context = {'form': form, 'course': course}
    return render(request, 'lms/instructor_edit_course.html', context)

@login_required
@require_http_methods(["POST"])
def instructor_delete_course(request, pk):
    try:
        instructor_profile = get_object_or_404(InstructorProfile, user=request.user)
    except Exception:
        messages.error(request, 'Profile error. Cannot delete course.')
        return redirect('instructor_my_courses')

    course = get_object_or_404(
        Course, 
        pk=pk, 
        instructor=instructor_profile
    )
    
    course_title = course.title
    
    try:
        course.delete()
        messages.success(request, f'Course "{course_title}" was successfully deleted. 🗑️')
    except Exception as e:
        messages.error(request, f'An error occurred while deleting "{course_title}": {e}')
        
    return redirect('instructor_my_courses')

# =========================================================
# STUDENT ENGAGEMENT VIEW (The main fix)
# =========================================================

@login_required
def my_courses_view(request):
    """
    Displays all courses the logged-in student is enrolled in, along with their progress.
    """
    try:
        # 1. Get the current user's StudentProfile
        student_profile = request.user.student_profile
    except StudentProfile.DoesNotExist:
        messages.error(request, "Student profile not found. Please register as a student.")
        return redirect('home')

    # 2. Fetch all Enrollment records for the student
    enrollments = Enrollment.objects.filter(
        student=student_profile
    ).select_related('course').prefetch_related(
        'course__modules__lessons' # Pre-fetch related content for efficiency
    ).order_by('-enrollment_date')
    
    # List to hold courses with progress data
    enrolled_courses_data = []

    for enrollment in enrollments:
        course = enrollment.course
        
        # --- PROGRESS CALCULATION LOGIC ---
        # A. Get total published lessons in the course
        total_lessons_count = Lesson.objects.filter(
            module__course=course
        ).count()
        
        # B. Get completed lessons for this specific enrollment
        completed_lessons_count = LessonProgress.objects.filter(
            enrollment=enrollment,
            is_completed=True
        ).count()
        
        # C. Calculate percentage
        if total_lessons_count > 0:
            progress = int((completed_lessons_count / total_lessons_count) * 100)
        else:
            progress = 0 # Course has no lessons yet
        
        # D. Check if course is now complete and update enrollment status if needed
        if course.content_complete and not enrollment.is_completed and progress == 100:
            if total_lessons_count > 0 and completed_lessons_count == total_lessons_count:
                enrollment.is_completed = True
                enrollment.completion_date = timezone.now()
                enrollment.save()
            
        # E. Attach necessary data to the course object dynamically
        course.progress = progress
        course.short_description = enrollment.course.short_description # Use the course field directly
        # The template uses course.image.url, which is available directly on the Course object
        
        # F. Add certificate information
        course.is_completed = enrollment.is_completed
        course.enrollment_id = enrollment.id
        
        # Check if certificate exists
        if hasattr(enrollment, 'certificate'):
            course.has_certificate = True
            course.certificate_id = enrollment.certificate.certificate_id
        else:
            course.has_certificate = False
        
        enrolled_courses_data.append(course)


    context = {
        'enrolled_courses': enrolled_courses_data, # This matches the key used in your HTML template
    }
    
    # RENDER THE CORRECT TEMPLATE NAME
    return render(request, 'lms/my_courses.html', context)

@login_required
def instructor_engagement_view(request):
    """Fetches and displays all enrollment records for the instructor's courses."""
    try:
        # CRITICAL: Ensure the user is an instructor
        instructor_profile = request.user.instructor_profile
    except InstructorProfile.DoesNotExist:
        messages.error(request, "Access Denied. You do not have an instructor profile.")
        return redirect('instructor_dashboard') 
    
    # Get all courses taught by this instructor
    instructor_courses = instructor_profile.courses.all()
    
    # Filter Enrollment records linked to these courses
    all_enrollments = Enrollment.objects.filter(
        course__in=instructor_courses
    ).select_related('student__user', 'course').order_by('-enrollment_date')
    
    context = {'all_enrollments': all_enrollments}
    
    # RENDER THE CORRECT TEMPLATE NAME
    return render(request, 'lms/instructor_engagement.html', context) 


@login_required
def instructor_course_progress(request, student_pk, course_pk):
    """
    Instructor-facing view to inspect a specific student's progress for a course.
    This is intentionally separate from the public `course_detail_view` which expects a course_slug.
    """
    # Ensure the requesting user is an instructor and owns the course
    try:
        instructor_profile = request.user.instructor_profile
    except InstructorProfile.DoesNotExist:
        messages.error(request, 'Access denied: not an instructor.')
        return redirect('home')

    course = get_object_or_404(Course, pk=course_pk)
    # Verify the instructor owns this course
    if course.instructor != instructor_profile:
        messages.error(request, 'You do not have permission to view this student progress for that course.')
        return redirect('instructor_engagement')

    student_profile = get_object_or_404(StudentProfile, pk=student_pk)
    # Get the enrollment record if it exists
    enrollment = Enrollment.objects.filter(student=student_profile, course=course).first()

    context = {
        'course': course,
        'student_profile': student_profile,
        'enrollment': enrollment,
    }

    return render(request, 'lms/instructor_course_progress.html', context)


# =========================================================
# COURSE BROWSING & ACCESS VIEWS
# =========================================================

def explore_courses_view(request):
    all_courses = Course.objects.filter(is_published=True).order_by('-created_at')
    context = {'courses': all_courses}
    return render(request, 'lms/explore_courses.html', context)

def course_detail_view(request, course_slug):
    course = get_object_or_404(Course, slug=course_slug, is_published=True)
    has_access = False
    is_enrolled = False
    can_enroll = False  # NEW: Flag to control the purchase button

    if request.user.is_authenticated:
        user = request.user
        is_instructor_or_admin = user.is_staff or hasattr(user, 'instructor_profile')
        
        # 1. Check if user is the Instructor of this specific course (grants full access)
        if hasattr(user, 'instructor_profile') and course.instructor == user.instructor_profile:
             has_access = True
             # If the instructor is viewing their own course, no other checks are needed
             # We explicitly DON'T set can_enroll for the instructor.
             
        # 2. Check if the user is a Student (for enrollment/access status)
        elif hasattr(user, 'student_profile'):
            student_profile = user.student_profile
            
            # Check if student is already enrolled
            if Enrollment.objects.filter(student=student_profile, course=course).exists():
                 has_access = True
                 is_enrolled = True
            else:
                 # User is an authenticated student and NOT enrolled, so they CAN enroll/purchase
                 can_enroll = True 
        
        # 3. If the user is logged in, but isn't the instructor/admin of this course 
        #    and isn't a student, they see the account type error message.

    context = {
        'course': course,
        'has_access': has_access,
        'is_logged_in': request.user.is_authenticated,
        'is_enrolled': is_enrolled,
        'can_enroll': can_enroll, # This will be True only for non-enrolled students
        'is_instructor_or_admin': is_instructor_or_admin if 'is_instructor_or_admin' in locals() else False # Optional: helps debug
    }
    return render(request, 'lms/course_detail.html', context)

@require_http_methods(["POST"])
def purchase_course(request):
    """
    Handles course purchase initiation - redirects to payment page for paid courses
    """
    if not request.user.is_authenticated:
        messages.warning(request, "Please log in to enroll in the course.")
        return redirect('student_login') 

    course_id = request.POST.get('course_id')
    course = get_object_or_404(Course, pk=course_id)
    
    try:
        student_profile = request.user.student_profile
        
        # Check if already enrolled
        existing_enrollment = Enrollment.objects.filter(
            student=student_profile, 
            course=course
        ).first()
        
        if existing_enrollment:
            messages.info(request, f'You are already enrolled in the course: "{course.title}".')
            return redirect('my_courses')
        
        # Handle FREE courses - enroll immediately
        if course.price <= 0:
            enrollment = Enrollment.objects.create(
                student=student_profile,
                course=course,
                progress_percentage=0,
                is_completed=False
            )
            messages.success(request, f'You are now successfully enrolled in the FREE course: "{course.title}"! 🎉')
            return redirect('my_courses')
        
        # Handle PAID courses - redirect to payment page
        else:
            return redirect('payment_page', course_id=course.id)
            
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Could not complete enrollment. Student profile not found.')
        return redirect('home')
    
    messages.error(request, 'Invalid request.')
    return redirect('explore_courses')


@login_required
def payment_page(request, course_id):
    """
    Display payment page for a course
    """
    course = get_object_or_404(Course, pk=course_id)
    
    try:
        student_profile = request.user.student_profile
        
        # Check if already enrolled
        if Enrollment.objects.filter(student=student_profile, course=course).exists():
            messages.info(request, 'You are already enrolled in this course.')
            return redirect('my_courses')
        
        # Check if it's a free course
        if course.price <= 0:
            messages.info(request, 'This is a free course. Redirecting to enrollment...')
            return redirect('purchase_course')
        
        context = {
            'course': course,
            'razorpay_key_id': settings.RAZORPAY_KEY_ID if hasattr(settings, 'RAZORPAY_KEY_ID') else ''
        }
        
        return render(request, 'lms/payment.html', context)
        
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Student profile not found.')
        return redirect('home')


@login_required
@require_http_methods(["POST"])
def process_payment(request):
    """
    Process card payment (simulation for now)
    """
    try:
        student_profile = request.user.student_profile
        course_id = request.POST.get('course_id')
        course = get_object_or_404(Course, pk=course_id)
        payment_method = request.POST.get('payment_method')
        
        # Check if already enrolled
        if Enrollment.objects.filter(student=student_profile, course=course).exists():
            messages.info(request, 'You are already enrolled in this course.')
            return redirect('my_courses')
        
        # Create enrollment
        enrollment = Enrollment.objects.create(
            student=student_profile,
            course=course,
            progress_percentage=0,
            is_completed=False
        )
        
        # Create payment record
        payment = Payment.objects.create(
            student=student_profile,
            course=course,
            enrollment=enrollment,
            amount=course.price,
            currency='INR',
            payment_method=payment_method,
            status='completed',
            billing_name=request.POST.get('cardholder_name', ''),
            billing_email=request.POST.get('email', request.user.email),
            billing_phone=request.POST.get('phone', ''),
            completed_at=timezone.now()
        )
        
        messages.success(request, f'Payment successful! You are now enrolled in "{course.title}". 💰')
        return redirect('payment_success', payment_id=payment.transaction_id)
        
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Student profile not found.')
        return redirect('home')
    except Exception as e:
        messages.error(request, f'Payment processing failed: {str(e)}')
        return redirect('payment_page', course_id=course_id)


@login_required
@csrf_exempt
@require_http_methods(["POST"])
def process_razorpay_payment(request):
    """
    Process Razorpay payment callback
    """
    try:
        data = json.loads(request.body)
        razorpay_payment_id = data.get('razorpay_payment_id')
        razorpay_order_id = data.get('razorpay_order_id', '')
        razorpay_signature = data.get('razorpay_signature', '')
        course_id = data.get('course_id')
        amount = data.get('amount')
        customer_name = data.get('customer_name', '')
        customer_email = data.get('customer_email', '')
        customer_phone = data.get('customer_phone', '')
        
        student_profile = request.user.student_profile
        course = get_object_or_404(Course, pk=course_id)
        
        # Verify payment with Razorpay (in production)
        # payment_details = razorpay_client.payment.fetch(razorpay_payment_id)
        
        # Check if already enrolled
        if Enrollment.objects.filter(student=student_profile, course=course).exists():
            return JsonResponse({
                'success': False,
                'error': 'Already enrolled in this course'
            })
        
        # Create enrollment
        enrollment = Enrollment.objects.create(
            student=student_profile,
            course=course,
            progress_percentage=0,
            is_completed=False
        )
        
        # Create payment record
        payment = Payment.objects.create(
            student=student_profile,
            course=course,
            enrollment=enrollment,
            amount=amount,
            currency='INR',
            payment_method='razorpay',
            status='completed',
            razorpay_payment_id=razorpay_payment_id,
            razorpay_order_id=razorpay_order_id,
            razorpay_signature=razorpay_signature,
            billing_name=customer_name,
            billing_email=customer_email,
            billing_phone=customer_phone,
            completed_at=timezone.now()
        )
        
        return JsonResponse({
            'success': True,
            'redirect_url': f'/payment/success/{payment.transaction_id}/'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })


@login_required
def payment_success(request, payment_id):
    """
    Payment success page
    """
    payment = get_object_or_404(Payment, transaction_id=payment_id, student=request.user.student_profile)
    
    context = {
        'payment': payment,
        'course': payment.course,
        'enrollment': payment.enrollment
    }
    
    return render(request, 'lms/payment_success.html', context)


@login_required
def payment_failure(request):
    """
    Payment failure page
    """
    return render(request, 'lms/payment_failure.html')

# [your_app_name]/views.py
# ... (Ensure InstructorProfileEditForm is imported) ...

@login_required
def instructor_edit_profile(request):
    """Allows instructor to edit their profile and flags for re-approval if necessary."""
    try:
        profile = request.user.instructor_profile
    except InstructorProfile.DoesNotExist:
        messages.error(request, "Profile not found. Please contact support.")
        return redirect('instructor_dashboard')

    if request.method == 'POST':
        # NOTE: Must include request.FILES to handle the image upload
        form = InstructorProfileEditForm(
            request.POST, 
            request.FILES, 
            instance=profile, 
            user_instance=request.user
        )
        if form.is_valid():
            profile_saved = form.save()
            
            # Display custom message from the form (if re-approval was triggered)
            if hasattr(profile_saved, '_message_on_save'):
                messages.warning(request, profile_saved._message_on_save)
            else:
                messages.success(request, 'Profile successfully updated!')

            # If the profile is no longer approved, redirect them away from the dashboard
            if not profile_saved.approved:
                 return redirect('home') # or a waiting page
                 
            return redirect('instructor_dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = InstructorProfileEditForm(
            instance=profile, 
            user_instance=request.user
        )

    context = {'form': form}
    # You will need to create this template: instructor_edit_profile.html
    return render(request, 'lms/instructor_edit_profile.html', context)


@login_required
@ensure_csrf_cookie
def instructor_manage_content(request, course_slug):
    # Ensure the user is the instructor of this course
    course = get_object_or_404(
        Course, 
        slug=course_slug, 
        instructor__user=request.user
    )
    
    # Pre-fetch modules and lessons for display
    modules = course.modules.all().prefetch_related('lessons')

    # Initialize all forms (Must be done BEFORE POST check, and pass 'course' to LessonContentForm)
    media_form = CourseCreationForm(instance=course)
    module_form = CourseModuleForm()
    lesson_form = LessonContentForm(course=course) # CRITICAL: Pass course instance here

    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'update_media':
            # This action handles updating the main course image, video, and notes
            media_form = CourseCreationForm(request.POST, request.FILES, instance=course)
            if media_form.is_valid():
                media_form.save() 
                messages.success(request, 'Course media updated successfully! 🖼️')
            else:
                messages.error(request, 'Error updating media.')

        elif action == 'create_module':
            # This action handles creating a new CourseModule
            module_form = CourseModuleForm(request.POST)
            if module_form.is_valid():
                new_module = module_form.save(commit=False)
                new_module.course = course # Link to the current course
                new_module.save()
                messages.success(request, f"Module '{new_module.title}' created. Add lessons now!")
            else:
                messages.error(request, 'Error creating module.')
        
        elif action == 'create_lesson':
            # This action handles creating a new Lesson with video/notes files
            lesson_form_posted = LessonContentForm(request.POST, request.FILES, course=course) # Re-initialize with course
            if lesson_form_posted.is_valid():
                new_lesson = lesson_form_posted.save(commit=False)
                
                # Retrieve the module based on the user's selection from the form
                # The form uses 'module_selection', but the model uses 'module'
                module_pk = lesson_form_posted.cleaned_data['module_selection'].pk
                new_lesson.module = CourseModule.objects.get(pk=module_pk, course=course)
                new_lesson.save()
                
                messages.success(request, f"Lesson '{new_lesson.title}' uploaded successfully. 🎥")
            else:
                messages.error(request, 'Error uploading lesson content. Check the module selection and required fields.')
                # If form is invalid, we must re-initialize the main lesson_form 
                # with the POST data to show errors on template reload.
                lesson_form = lesson_form_posted 

        elif action == 'delete_lesson':
            # Handle deletion of a lesson from the instructor manage content page
            lesson_id = request.POST.get('lesson_id')
            if lesson_id:
                try:
                    lesson_obj = get_object_or_404(Lesson, pk=int(lesson_id))
                    # Ensure the lesson belongs to this course
                    if lesson_obj.module and lesson_obj.module.course == course:
                        title = lesson_obj.title
                        lesson_obj.delete()
                        messages.success(request, f"Lesson '{title}' deleted successfully.")
                    else:
                        messages.error(request, 'Cannot delete lesson: permission denied or lesson not in this course.')
                except Exception as e:
                    messages.error(request, f'Error deleting lesson: {e}')
            else:
                messages.error(request, 'No lesson specified to delete.')

        elif action == 'toggle_content_complete':
            # Toggle the content_complete status
            course.content_complete = not course.content_complete
            course.save()
            if course.content_complete:
                messages.success(request, '✓ Course content marked as complete! Students can now earn certificates upon completion.')
            else:
                messages.warning(request, '⚠ Course marked as incomplete. Certificate generation is disabled.')

        # Always redirect after POST to prevent duplicate submissions
        return redirect('instructor_manage_content', course_slug=course.slug)

    # Re-fetch modules after potential update
    modules = course.modules.all().prefetch_related('lessons')

    context = {
        'course': course,
        # Pass the forms back to the template, including the re-initialized invalid form if POST failed
        'media_form': media_form,
        'module_form': module_form,
        'lesson_form': lesson_form, 
        'modules': modules, 
    }
    return render(request, 'lms/instructor_manage_content.html', context)


@login_required
def instructor_edit_lesson(request, course_slug, lesson_pk):
    """Allow instructor to edit a specific lesson for their course."""
    # Ensure the user owns the course
    course = get_object_or_404(Course, slug=course_slug, instructor__user=request.user)
    lesson = get_object_or_404(Lesson, pk=lesson_pk, module__course=course)

    if request.method == 'POST':
        # Handle special removal actions first
        action = request.POST.get('action')
        if action == 'remove_video':
            if lesson.video_file:
                try:
                    lesson.video_file.delete(save=False)
                    lesson.video_file = None
                    lesson.save()
                    messages.success(request, 'Video removed successfully.')
                except Exception as e:
                    messages.error(request, f'Error removing video: {e}')
            else:
                messages.error(request, 'No video to remove.')
            return redirect('instructor_edit_lesson', course_slug=course.slug, lesson_pk=lesson.pk)

        if action == 'remove_pdf':
            if lesson.notes_pdf:
                try:
                    lesson.notes_pdf.delete(save=False)
                    lesson.notes_pdf = None
                    lesson.save()
                    messages.success(request, 'PDF notes removed successfully.')
                except Exception as e:
                    messages.error(request, f'Error removing PDF: {e}')
            else:
                messages.error(request, 'No PDF to remove.')
            return redirect('instructor_edit_lesson', course_slug=course.slug, lesson_pk=lesson.pk)

        if action == 'upload_video':
            # Replace existing video with uploaded file
            upload = request.FILES.get('video_upload')
            if upload:
                try:
                    # delete old file first to avoid orphaned storage
                    if lesson.video_file:
                        lesson.video_file.delete(save=False)
                    lesson.video_file = upload
                    lesson.save()
                    messages.success(request, 'Video uploaded successfully.')
                except Exception as e:
                    messages.error(request, f'Error uploading video: {e}')
            else:
                messages.error(request, 'No video file provided for upload.')
            return redirect('instructor_edit_lesson', course_slug=course.slug, lesson_pk=lesson.pk)

        if action == 'upload_pdf':
            upload = request.FILES.get('pdf_upload')
            if upload:
                try:
                    if lesson.notes_pdf:
                        lesson.notes_pdf.delete(save=False)
                    lesson.notes_pdf = upload
                    lesson.save()
                    messages.success(request, 'PDF uploaded successfully.')
                except Exception as e:
                    messages.error(request, f'Error uploading PDF: {e}')
            else:
                messages.error(request, 'No PDF file provided for upload.')
            return redirect('instructor_edit_lesson', course_slug=course.slug, lesson_pk=lesson.pk)

        # Otherwise, treat as standard edit/save
        form = LessonContentForm(request.POST, request.FILES, instance=lesson, course=course)
        if form.is_valid():
            edited = form.save(commit=False)
            # Update module if module_selection provided
            module_selected = form.cleaned_data.get('module_selection')
            if module_selected and module_selected.course == course:
                edited.module = module_selected
            # If a new file was uploaded, Django will handle replacing the file on save
            edited.save()
            messages.success(request, f"Lesson '{edited.title}' updated successfully.")
            return redirect('instructor_manage_content', course_slug=course.slug)
        else:
            messages.error(request, 'There was an error updating the lesson. Please check the fields.')
    else:
        form = LessonContentForm(instance=lesson, course=course)
        # pre-select the current module in the module_selection field
        try:
            form.fields['module_selection'].initial = lesson.module
        except Exception:
            pass

    context = {'course': course, 'form': form, 'lesson': lesson}
    return render(request, 'lms/instructor_edit_lesson.html', context)

class CourseModuleForm(forms.ModelForm):
    class Meta:
        model = CourseModule
        fields = ['title', 'description', 'order']
        widgets = {
            # Apply the class directly to the widget
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'order': forms.NumberInput(attrs={'class': 'form-control'}),
        }
# =========================================================
# PLACEHOLDER/STUB VIEWS (Removed conflicting instructor_engagement stub)
# =========================================================

def instructor_manage_courses(request):
    # This might need to be consolidated with instructor_my_courses
    return render(request, 'lms/instructordash.html')

def instructor_add_quiz(request):
    return render(request, 'lms/instructordash.html')

def instructor_create_coupon(request):
    return render(request, 'lms/instructordash.html')

def instructor_request_payout(request):
    return render(request, 'lms/instructordash.html')


@login_required
def course_lessons_view(request, course_slug):
    """Display course lessons for enrolled students."""
    course = get_object_or_404(Course, slug=course_slug)
    
    # Check if student is enrolled in the course
    try:
        student_profile = request.user.student_profile
        enrollment = Enrollment.objects.get(student=student_profile, course=course)
    except (StudentProfile.DoesNotExist, Enrollment.DoesNotExist):
        messages.error(request, "You are not enrolled in this course or do not have access.")
        return redirect('explore_courses')
    
    # Check if course is now complete and update enrollment status if needed
    if course.content_complete and not enrollment.is_completed and enrollment.progress_percentage == 100:
        total_lessons = Lesson.objects.filter(module__course=course).count()
        completed_lessons = LessonProgress.objects.filter(
            enrollment=enrollment,
            is_completed=True
        ).count()
        
        # If all lessons are completed and course is now marked complete, update enrollment
        if total_lessons > 0 and completed_lessons == total_lessons:
            enrollment.is_completed = True
            enrollment.completion_date = timezone.now()
            enrollment.save()
            messages.success(request, '🎉 Congratulations! This course is now complete and you can generate your certificate!')
    
    # Get all modules and lessons for this course
    modules = course.modules.all().prefetch_related('lessons')
    
    context = {
        'course': course,
        'modules': modules,
        'enrollment': enrollment,
    }
    
    return render(request, 'lms/course_lessons.html', context)


@login_required
@ensure_csrf_cookie
def lesson_detail_view(request, course_slug, lesson_id):
    """Display a specific lesson with video and PDF."""
    course = get_object_or_404(Course, slug=course_slug)
    lesson = get_object_or_404(Lesson, pk=lesson_id, module__course=course)
    
    # Check if student is enrolled
    try:
        student_profile = request.user.student_profile
        enrollment = Enrollment.objects.get(student=student_profile, course=course)
    except (StudentProfile.DoesNotExist, Enrollment.DoesNotExist):
        messages.error(request, "You are not enrolled in this course or do not have access.")
        return redirect('explore_courses')
    
    # Get or create lesson progress
    lesson_progress, created = LessonProgress.objects.get_or_create(
        enrollment=enrollment,
        lesson=lesson
    )
    
    # Mark as completed if requested
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'mark_complete':
            lesson_progress.is_completed = True
            lesson_progress.completion_date = timezone.now()
            lesson_progress.save()
            
            # Update course progress percentage
            # total_lessons should be the number of lessons in the course (not number of modules)
            total_lessons = Lesson.objects.filter(module__course=course).count()
            completed_lessons = LessonProgress.objects.filter(
                enrollment=enrollment,
                is_completed=True
            ).count()
            
            if total_lessons > 0:
                enrollment.progress_percentage = int((completed_lessons / total_lessons) * 100)
                
                # Check if course is now fully completed
                # Only mark as complete if instructor has marked course content as complete
                if completed_lessons == total_lessons and course.content_complete:
                    enrollment.is_completed = True
                    enrollment.completion_date = timezone.now()
                    messages.success(request, '🎉 Congratulations! You have completed all lessons in this course!')
                elif completed_lessons == total_lessons and not course.content_complete:
                    messages.info(request, '📚 You have completed all available lessons! The instructor is still adding more content to this course.')
                
                enrollment.save()
            
            messages.success(request, '✓ Lesson marked as complete!')
            return redirect('lesson_detail', course_slug=course_slug, lesson_id=lesson_id)
    
    context = {
        'course': course,
        'lesson': lesson,
        'lesson_progress': lesson_progress,
        'is_instructor_of_course': hasattr(request.user, 'instructor_profile') and request.user.is_authenticated and course.instructor == getattr(request.user, 'instructor_profile', None),
    }
    
    return render(request, 'lms/lesson_detail.html', context)


@login_required
@require_http_methods(["POST"])
def set_lesson_duration(request, course_slug, lesson_pk):
    """AJAX endpoint: set lesson duration (seconds) to minutes extracted client-side.
    Only the course instructor may update duration via this endpoint.
    Expects JSON body: {"duration_seconds": <number>} or form-encoded POST.
    """
    course = get_object_or_404(Course, slug=course_slug)
    # Ensure the requesting user is the instructor of this course
    try:
        instructor_profile = request.user.instructor_profile
    except InstructorProfile.DoesNotExist:
        return JsonResponse({'error': 'Permission denied'}, status=403)

    if course.instructor != instructor_profile:
        return JsonResponse({'error': 'Permission denied'}, status=403)

    lesson = get_object_or_404(Lesson, pk=lesson_pk, module__course=course)

    # Parse incoming duration
    duration_seconds = None
    if request.content_type == 'application/json':
        import json
        try:
            payload = json.loads(request.body.decode('utf-8') or '{}')
            duration_seconds = float(payload.get('duration_seconds') or 0)
        except Exception:
            duration_seconds = None
    else:
        try:
            duration_seconds = float(request.POST.get('duration_seconds') or 0)
        except Exception:
            duration_seconds = None

    if not duration_seconds or duration_seconds <= 0:
        return JsonResponse({'error': 'Invalid duration'}, status=400)

    # Convert to minutes (rounded)
    minutes = int(round(duration_seconds / 60.0))
    if minutes <= 0:
        minutes = 1

    lesson.duration_minutes = minutes
    lesson.save()

    return JsonResponse({'status': 'ok', 'minutes': minutes})


# The remaining course category stubs:
def course_python(request):
    return render(request, 'lms/python.html')
def course_javascript(request):
    return render(request, 'lms/javascript.html')
def course_java(request):
    return render(request, 'lms/Java.html')
def course_cpp(request):
    return render(request, 'lms/C++.html')


def create_order(request):
    """Create Razorpay order and render payment page"""
    if request.method == "POST":
        amount = 500  # Amount in paise (50000 paise = ₹500, main_amount * 100)
        currency = "INR"
        
        # Create Razorpay order
        payment_order = razorpay_client.order.create({
            'amount': amount,
            'currency': currency,
            'payment_capture': '1'  # Auto capture payment
        })
        
        order_id = payment_order['id']
        
        context = {
            'order_id': order_id,
            'razorpay_key_id': settings.RAZORPAY_KEY_ID,
            'amount': amount,
            'currency': currency,
        }
        
        return render(request, 'payment.html', context)
    
    return redirect('home')


@csrf_exempt
def payment_callback(request):
    """Handle Razorpay payment callback"""
    if request.method == "POST":
        try:
            # Get payment details
            payment_id = request.POST.get('razorpay_payment_id')
            order_id = request.POST.get('razorpay_order_id')
            signature = request.POST.get('razorpay_signature')
            
            # Verify payment signature
            params_dict = {
                'razorpay_order_id': order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
            
            razorpay_client.utility.verify_payment_signature(params_dict)
            
            # Payment is successful
            # You can save payment details to database here
            
            return render(request, 'success.html', {
                'payment_id': payment_id,
                'order_id': order_id
            })
            
        except razorpay.errors.SignatureVerificationError:
            # Payment verification failed
            return render(request, 'failure.html')
    
    return redirect('home')


# =========================================================
# CERTIFICATE VIEWS
# =========================================================

@login_required
def generate_certificate(request, enrollment_id):
    """
    Generate a certificate for a completed course
    """
    try:
        student_profile = request.user.student_profile
        enrollment = get_object_or_404(
            Enrollment, 
            id=enrollment_id, 
            student=student_profile,
            is_completed=True
        )
        
        # Check if course content is complete
        if not enrollment.course.content_complete:
            messages.error(request, 'The instructor is still adding content to this course. Certificate will be available once the course is fully complete.')
            return redirect('my_courses')
        
        # Check if certificate already exists
        if hasattr(enrollment, 'certificate'):
            messages.info(request, 'Certificate already exists for this course.')
            return redirect('view_certificate', certificate_id=enrollment.certificate.certificate_id)
        
        # Get course details
        course = enrollment.course
        instructor = course.instructor
        
        # Count lessons
        total_lessons = Lesson.objects.filter(module__course=course).count()
        completed_lessons = LessonProgress.objects.filter(
            enrollment=enrollment,
            is_completed=True
        ).count()
        
        # Create certificate
        certificate = Certificate.objects.create(
            enrollment=enrollment,
            student=student_profile,
            course=course,
            student_name=request.user.get_full_name() or request.user.username,
            course_title=course.title,
            instructor_name=instructor.user.get_full_name() or instructor.user.username,
            completion_date=enrollment.completion_date or timezone.now().date(),
            total_lessons=total_lessons,
            completed_lessons=completed_lessons
        )
        
        # Generate QR code
        import qrcode
        from io import BytesIO
        from django.core.files import File
        
        # Create verification URL
        verification_url = request.build_absolute_uri(
            f'/certificate/verify/{certificate.certificate_id}/'
        )
        certificate.verification_url = verification_url
        
        # Generate QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(verification_url)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        
        certificate.qr_code.save(
            f'qr_{certificate.certificate_id}.png',
            File(buffer),
            save=True
        )
        
        messages.success(request, 'Certificate generated successfully! 🎓')
        return redirect('view_certificate', certificate_id=certificate.certificate_id)
        
    except StudentProfile.DoesNotExist:
        messages.error(request, 'Student profile not found.')
        return redirect('my_courses')
    except Exception as e:
        messages.error(request, f'Error generating certificate: {str(e)}')
        return redirect('my_courses')


@login_required
def view_certificate(request, certificate_id):
    """
    View a specific certificate
    """
    certificate = get_object_or_404(Certificate, certificate_id=certificate_id)
    
    # Check if user is authorized to view
    if certificate.student != request.user.student_profile:
        messages.error(request, 'You are not authorized to view this certificate.')
        return redirect('my_courses')
    
    context = {
        'certificate': certificate,
        'course': certificate.course,
        'student': certificate.student,
    }
    
    return render(request, 'lms/certificate.html', context)


def verify_certificate(request, certificate_id):
    """
    Public certificate verification page
    """
    try:
        certificate = get_object_or_404(Certificate, certificate_id=certificate_id)
        
        context = {
            'certificate': certificate,
            'is_valid': True,
        }
        
        return render(request, 'lms/certificate_verification.html', context)
        
    except Certificate.DoesNotExist:
        context = {
            'is_valid': False,
            'certificate_id': certificate_id,
        }
        return render(request, 'lms/certificate_verification.html', context)


@login_required
def download_certificate(request, certificate_id):
    """
    Download certificate as PDF
    """
    from django.http import HttpResponse
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib import colors
    import os
    
    certificate = get_object_or_404(Certificate, certificate_id=certificate_id)
    
    # Check authorization
    if certificate.student != request.user.student_profile:
        messages.error(request, 'Unauthorized access.')
        return redirect('my_courses')
    
    # Create PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="certificate_{certificate.certificate_id}.pdf"'
    
    # Create canvas
    p = canvas.Canvas(response, pagesize=landscape(A4))
    width, height = landscape(A4)
    
    # Draw border
    p.setStrokeColor(colors.HexColor('#1e40af'))
    p.setLineWidth(3)
    p.rect(30, 30, width-60, height-60)
    
    p.setStrokeColor(colors.HexColor('#3b82f6'))
    p.setLineWidth(1)
    p.rect(40, 40, width-80, height-80)
    
    # Title
    p.setFont("Helvetica-Bold", 40)
    p.setFillColor(colors.HexColor('#1e40af'))
    p.drawCentredString(width/2, height-100, "CERTIFICATE OF COMPLETION")
    
    # Subtitle
    p.setFont("Helvetica", 16)
    p.setFillColor(colors.HexColor('#64748b'))
    p.drawCentredString(width/2, height-140, "This is to certify that")
    
    # Student name
    p.setFont("Helvetica-Bold", 32)
    p.setFillColor(colors.HexColor('#0f172a'))
    p.drawCentredString(width/2, height-190, certificate.student_name)
    
    # Has completed
    p.setFont("Helvetica", 16)
    p.setFillColor(colors.HexColor('#64748b'))
    p.drawCentredString(width/2, height-230, "has successfully completed the course")
    
    # Course title
    p.setFont("Helvetica-Bold", 24)
    p.setFillColor(colors.HexColor('#1e40af'))
    p.drawCentredString(width/2, height-270, certificate.course_title)
    
    # Course details
    p.setFont("Helvetica", 12)
    p.setFillColor(colors.HexColor('#475569'))
    details_text = f"Completed {certificate.completed_lessons} of {certificate.total_lessons} lessons"
    p.drawCentredString(width/2, height-310, details_text)
    
    # Completion date
    p.setFont("Helvetica", 14)
    p.setFillColor(colors.HexColor('#0f172a'))
    date_text = f"Completion Date: {certificate.completion_date.strftime('%B %d, %Y')}"
    p.drawCentredString(width/2, height-350, date_text)
    
    # Instructor signature
    p.setFont("Helvetica", 12)
    p.setFillColor(colors.HexColor('#64748b'))
    p.drawString(150, 120, "Instructor:")
    p.setFont("Helvetica-Bold", 14)
    p.setFillColor(colors.HexColor('#0f172a'))
    p.drawString(150, 100, certificate.instructor_name)
    p.line(150, 95, 350, 95)
    
    # Certificate ID
    p.setFont("Helvetica", 10)
    p.setFillColor(colors.HexColor('#64748b'))
    p.drawRightString(width-150, 120, f"Certificate ID: {certificate.certificate_id}")
    p.drawRightString(width-150, 100, f"Issue Date: {certificate.issue_date.strftime('%B %d, %Y')}")
    
    # QR Code
    if certificate.qr_code:
        try:
            qr_path = certificate.qr_code.path
            if os.path.exists(qr_path):
                qr_image = ImageReader(qr_path)
                p.drawImage(qr_image, width-200, 130, width=80, height=80, mask='auto')
                p.setFont("Helvetica", 8)
                p.drawCentredString(width-160, 115, "Scan to verify")
        except:
            pass
    
    # Footer
    p.setFont("Helvetica-Oblique", 10)
    p.setFillColor(colors.HexColor('#94a3b8'))
    p.drawCentredString(width/2, 60, "LearnCode - Online Learning Platform")
    p.drawCentredString(width/2, 45, f"Verify at: {certificate.verification_url}")
    
    p.showPage()
    p.save()
    
    return response


# =========================================================
# SUPPORT AND ABOUT US VIEWS
# =========================================================

def about_us(request):
    """
    About Us page with company information and contact details
    """
    context = {
        'company_name': 'LearnCode Academy',
        'address': 'Sector 62, Noida, Uttar Pradesh 201301, India',
        'support_phone': '+91-9876543210',
        'support_email': 'support@learncode.com',
        'business_hours': 'Monday - Saturday: 9:00 AM - 6:00 PM',
    }
    return render(request, 'lms/about_us.html', context)


def support_page(request):
    """
    Support page with form - accessible to all users
    """
    initial_data = {}
    
    # Pre-fill user data if user is authenticated
    if request.user.is_authenticated:
        initial_data = {
            'name': request.user.get_full_name() or request.user.username,
            'email': request.user.email,
        }
        
        # Get user's phone if available
        if hasattr(request.user, 'student_profile'):
            initial_data['phone'] = request.user.student_profile.contact
        elif hasattr(request.user, 'instructor_profile'):
            initial_data['phone'] = request.user.instructor_profile.contact
    
    return render(request, 'lms/support.html', {'initial_data': initial_data})


@login_required
def submit_support_ticket(request):
    """
    Handle support ticket submission
    """
    if request.method == 'POST':
        from .models import SupportTicket
        
        name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip()
        phone = request.POST.get('phone', '').strip()
        subject = request.POST.get('subject', '').strip()
        message = request.POST.get('message', '').strip()
        
        # Validation
        if not all([name, email, phone, subject, message]):
            messages.error(request, 'All fields are required.')
            return redirect('support_page')
        
        # Create ticket
        ticket = SupportTicket.objects.create(
            user=request.user,
            name=name,
            email=email,
            phone=phone,
            subject=subject,
            message=message,
            status='open'
        )
        
        messages.success(request, f'✓ Support ticket #{ticket.ticket_id} created successfully! Our team will contact you soon.')
        return redirect('my_tickets')
    
    return redirect('support_page')


@login_required
def my_tickets(request):
    """
    View user's support tickets
    """
    from .models import SupportTicket
    
    tickets = SupportTicket.objects.filter(user=request.user).order_by('-created_at')
    
    context = {
        'tickets': tickets,
        'open_count': tickets.filter(status='open').count(),
        'closed_count': tickets.filter(status='closed').count(),
    }
    
    return render(request, 'lms/my_tickets.html', context)


